import os
import pandas as pd
from databricks import sql
from typing import List, Optional, Tuple
import pyarrow
from github import Github
import re
from dotenv import load_dotenv
import openai
import logging
import requests
from openai.types.chat.chat_completion import ChatCompletion
import httpx
import streamlit as st
import base64
from io import StringIO, BytesIO
from PIL import Image
load_dotenv()
API_ENDPOINT = os.getenv("API_ENDPOINT")
API_TOKEN = os.getenv("API_TOKEN")
API_BASE = os.getenv("API_BASE")
TIMEOUT = 60.0
MODEL = os.getenv("MODEL")
 
logger = logging.getLogger(__name__)
 
client = openai.OpenAI(
    base_url=API_BASE, api_key=API_TOKEN, timeout=httpx.Timeout(TIMEOUT)
)

list_of_tables = set()
 
# Define a custom exception for DB timeout
class DBxTimeoutError(Exception):
    pass
 
def get_connector():
    print("Connector running")
    try:
        print("Entered connector try")
        return sql.connect(
            server_hostname=os.getenv("databricks_hostname"),
            http_path=os.getenv("databricks_http_path"),
            access_token=os.getenv("DATABRICKS_ACCESS_TOKEN"),
        )
    except TimeoutError as exc:
        print("Entered timeout error")
        raise DBxTimeoutError() from exc
    except Exception as exc:
        print("Entered exception error")
        raise Exception(f"Connection failed: {exc}") from exc
 
def save_to_excel(content: pd.DataFrame, file_path: str):
    """Function to save content (query result or error) to an Excel file."""
    try:
        content.to_excel(file_path, index=False, engine='openpyxl')
        print(f"Content saved to {file_path}")
    except Exception as e:
        print(f"Error saving to Excel: {e}")
 
def run_sql_query(query: str) -> Tuple[Optional[str], Optional[str]]:
    print("Running query:", query)
    try:
        connector = get_connector()
        print("Connection established")
       
        with connector as conn:
            with conn.cursor() as cursor:
                cursor.execute(query)
                result = cursor.fetchall()
                return result if result else None, None
    except DBxTimeoutError:
        return None, "Databricks connection timed out"
    except Exception as e:
        return None, f"Error executing query: {e}"
 
 
def refine_sql_result(databricks_output):
    # print("#############",databricks_output[0][0])
    return databricks_output[0][0] if databricks_output else None
   
def get_create_table_statements(table_names: List[str]) -> pd.DataFrame:
    results = []
    for table in table_names:
       
        query = f"SHOW CREATE TABLE {table};"
        databricks_output, error = run_sql_query(query)
        # print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@",databricks_output,"/////////",error)
        create_stmt=refine_sql_result(databricks_output)
        if create_stmt:
            results.append({"Table Name": table, "Create Statement": create_stmt})
        else :
 
            # print(f"Error for table {table}: {error}")
            table_name = table.split(".")[-1]  # Extract table name for GitHub search
            print("Fetching CREATE statement from GitHub for table:", table_name)
            git_sql_query = get_create_sql_from_git(table_name)
           
            if git_sql_query:
                results.append({"Table Name": table, "Create Statement": git_sql_query})
            else:
                results.append({"Table Name": table, "Create Statement": "No SQL query"})
 
 
            # table_name=table.split(".")[-1]
            # print("table_name:",table_name)
            # git_sql_query=get_create_sql_from_git(table_name)
            # results.append({"Table Name": table, "Create Statement": git_sql_query})
 
   
    return pd.DataFrame(results)
 
def find_file_in_github_repo(repo_name, file_pattern,file_path='', access_token=None):
    """
    Finds files in a GitHub repository based on a regex pattern.
 
    :param repo_name: Name of the repository (e.g., "username/repo").
    :param file_pattern: Regex pattern to match filenames (e.g., r'.*\.json$', r'^config.*').
    :param access_token: GitHub Personal Access Token for authentication (optional for public repos).
    :return: List of matching file paths.
    """
    print("Entered find files in github repo function")
    try:
        # Authenticate with GitHub
        g = Github(access_token) if access_token else Github()
        # Get the repository
        repo = g.get_repo(repo_name)
        # Get the list of all files in the repository
        contents = repo.get_contents("")
        print("content is : ",contents)
        all_files = []
 
        while contents:
 
            # print("Entered while loop")
            file_content = contents.pop(0)
            if file_content.type == "dir":
                # print("Entered in if condition")
                contents.extend(repo.get_contents(file_content.path))
                # print(contents)
            else:
                # print("Entered in else condition")
                all_files.append(file_content.path)
        print(all_files)
 
        # Filter files matching the regex pattern
        matching_files = [file for file in all_files if re.search(file_pattern, file)]
 
        return matching_files
   
    except Exception as e:
        print(f"An error occurred: {e}")
        return []
 
def get_file_content(repo_name, file_path, access_token=None):
    """
    Retrieves the content of a specific file in a GitHub repository.
 
    :param repo_name: Name of the repository (e.g., "username/repo").
    :param file_path: Path of the file in the repository (e.g., "src/config.json").
    :param access_token: GitHub Personal Access Token for authentication (optional for public repos).
    :return: File content as a string.
    """
    print("Entered get_file_content function")
    try:
        # Authenticate with GitHub
        g = Github(access_token) if access_token else Github()
        # Get the repository
        repo = g.get_repo(repo_name)
        # Get the file content
        file_content = repo.get_contents(file_path)
        print("Returning file contents")
        return file_content.decoded_content.decode("utf-8")
 
    except Exception as e:
        print(f"An error occurred while fetching file content: {e}")
        return None
 
 
 
 
def get_create_sql_from_git(table_name):
    # Replace with your GitHub repo (e.g., "octocat/Hello-World")
    # repository_name = "bayer-int/D1LH-PLAT-DBX-Artifacts/blob/master/metadata/Asset_View_Metadata/SCL/ASSET/SD"
    repository_name = "bayer-int/D1LH-PLAT-DBX-Artifacts"
 
    # Correct folder path in the repo
    folder_path = "metadata/Asset_View_Metadata/SCL/ASSET/SD"
    name=table_name
 
    # Regex pattern to match the target file (e.g., all JSON files)
    file_regex = rf".*{name}\.json$"
 
    # Optional: Add your GitHub access token here (especially for private repos)
    github_token = "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"  # Replace with your PAT or None for public repos
    #github_token = os.getenv("GITHUB_TOKEN")  
 
    print(f"Searching for files matching '{file_regex}' in the GitHub repository '{repository_name}'...")
    #print("repostory_name",repository_name, file_regex)
    found_files = find_file_in_github_repo(repository_name, file_regex,folder_path,github_token)
    #print("@@@@@",found_files)
    if found_files:
        # print(f"Found {len(found_files)} file(s):")
        # for file in found_files:
        #     print(f" - {file}")
        # Fetch content of the first matched file
        selected_file = found_files[0]
        # print(f"\nFetching content of the file: {selected_file}...")
 
        file_content = get_file_content(repository_name, selected_file, github_token)
   
        if file_content:
            # print(f"Content of '{selected_file}':\n")
            return file_content
        else:
            print("Could not retrieve the file content.")
        return None
    else:
        print(f"No files matching '{file_regex}' were found.")
        return None
def analyze_sql_queries_from_excel(file_path: str):
    df = pd.read_excel(file_path, engine='openpyxl')
    if "Create Statement" not in df.columns:
        raise ValueError("Excel file must contain a column named 'Create Statement'")
    # if "Create Statement"!="No SQL query":
           
    results = []
    numeric_results = []
    for sql_query in df["Create Statement"].dropna():
        prompt = f"""
       Instructions:
        - you are passed a query that will create a table or view in databricks.
        - /n query : {sql_query} /n
        - You need to count the the total number of transformations in the SQL that are doing data manipulation.
        - Consider transformations like :  format conversion, datetime conversion,unit conversion, string operations ,CASE statements, string conversions, currency conversions and count it seperately for each column in select statement .
        - Do not consider case statement within the where clause and any transformation within the case statement in the where clause
        - If there are nested transformations in same column or field consider them as individual transformations for each field .Example :sha1(cast(scl_sd_shpmt_cond_letra.`SHPMT_COST_ITM__AENAM` as string)) . It has 2 transformations sha1 and cast.
        - However, If the column names indicate currency related transformations, do not include them in the transformations.
        - Ignore filter conditions in where clause 
        - Ignore IN and LIKE clauses
        - If the file is in json consider filters.
        - Ignore conditions and filters applied on tables containing the keyword 'auth'.
        - Ignore operations related to 'ELSA-DLDB-P-AR-POWERANALYST-DIV'.
        - Show the operations used in the count.
        - Ignore aliases and comments.
        - Exclude comments from the query
        - In last line of result give the output of transformation as **TOTAL TRANSFORMATION=** and the result should be only a numeric value.
        - If the query is equal to "No SQL query" then give **TOTAL TRANSFORMATION=0**
        """
        message = [{"role": "user", "content": prompt}]
        result, error = chat_completion(message, MODEL, "text")  
        response_text = result.choices[0].message.content if result else error
        results.append(response_text)
        numeric_results.append(extract_numeric_value(response_text))
    
    df["Analysis Result"] = results  # Add results as a new column
    df["Total Transformations"] = numeric_results  # Add numeric value as a separate column
    df.to_excel(file_path, index=False, engine='openpyxl')  # Save to the same file
    print(f"Results saved to {file_path}")

 
def chat_completion(
    messages: list,    
    model: str,
    response_format: str = "text",
) -> Tuple[Optional[ChatCompletion], Optional[str]]:
 
    try:
        response = client.chat.completions.create(
            model=model,
            messages=messages,            
            response_format={"type": response_format},
        )        
        return response, None
    except openai.APITimeoutError:
        return None, f"Time out error: Request timed out after {TIMEOUT} seconds."
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return (
            None,
            "Unexpected error occurred when calling openai.ChatCompletion function.",
        )
 
def extract_numeric_value(text: str) -> int:
    match = re.search(r'TOTAL TRANSFORMATION=(\d+)', text)
    return int(match.group(1)) if match else None
 
def sum_total_transformations(file_path):
    df = pd.read_excel(file_path)  # Load the Excel file
    total_sum = df["Total Transformations"].sum()  # Sum the column
    return total_sum
 
def layer_finding(user_input):
    Layer_query=f"select count(distinct(source_table_schema)) from system.access.table_lineage  where  target_table_full_name like '%{user_input}' and target_table_catalog='efdataonelh_prd' and source_table_schema not like '%auth%'"  
    layer_output,layer_error=run_sql_query(Layer_query)
    return layer_output
 
def direct_asset(user_input):
    direct_asset_query=f"select count(distinct(source_table_full_name)) from system.access.table_lineage  where  target_table_full_name like '%{user_input}' and target_table_catalog='efdataonelh_prd'and source_table_full_name not like '%auth%'"  
    direct_asset_output,direct_asset_error=run_sql_query(direct_asset_query)
    return direct_asset_output
 
def extracting_all_input_tables(user_input):
    # Initialize an empty set to store the sources
    sources = set()
    list_of_tables = []
    index = 0
    # Start with the provided table name in the current_tables list
    list_of_tables = [f"efdataonelh_prd.{user_input}"]
   
    # Loop until there are no more tables to process
    
    while index < len(list_of_tables):
        print("!!!!!!!!!!!!!",list_of_tables[index])
        query = f"""
        SELECT DISTINCT source_table_full_name AS source_table_name
        FROM system.access.table_lineage
        WHERE target_table_catalog = 'efdataonelh_prd'
        AND target_table_full_name = '{list_of_tables[index]}'
        AND source_table_full_name NOT REGEXP 'auth|staging|parking|none'
        AND target_table_full_name NOT REGEXP 'auth|staging|parking|none';
        """
       
        result, error = run_sql_query(query)
        print ("Result of current tables:", result)
        # If there's an error, log it and break
        if error:
            print(f"SQL query error: {error}")
            break
 
        # Ensure result is not None before processing
        if result is None:
            print("Warning: Query returned None. Skipping iteration.")
            break
        
        for i, row in enumerate(result):
            print(f"Index: {i}, Source Table: {row.source_table_name}")
            list_of_tables.append(row.source_table_name)
            # index = index +1
        print("Printing list of objects:",list_of_tables)
        # new_sources = {row[0] for row in result} if result else set()
        # sources.update(new_sources)
 
        # Update current_tables with the new source tables for the next iteration
        # current_tables = list(new_sources) if new_sources else []
        index=index+1
    # Collect and display the final result
    # output_tables = list(sources)
    print(f"Output for input 'efdataonelh_prd.{user_input}': {list_of_tables}")
    return list_of_tables
 
 
st.markdown("<h1 style='white-space: nowrap;'>Lakehouse Complexity Matrix Assessment</h1>", unsafe_allow_html=True)
# user_input=st.text_input("### Enter Lakehouse Asset Name")
st.write("### Enter Lakehouse Asset Name")
user_input = st.text_input("")
# image = Image.open("input_image.jpg")
# buffered = BytesIO()
# image.save(buffered, format="JPEG")
# base64_image = base64.b64encode(buffered.getvalue()).decode("utf-8")
# st.markdown(
#         f"""
#         <style>
#             .stApp {{
#                 background-image: url('data:image/jpeg;base64,{base64_image}');
#                 background-size: cover;
#             }}      
#         </style>
#         """,
#         unsafe_allow_html=True
#         )
 
if user_input:
    if st.button("Process"):
        st.write("### Processing Started...")
        table_names = extracting_all_input_tables(user_input)
 
        count_of_all_tables = len(table_names)
        st.write("### Extracting Tables ...")
        # table_names.append("efdataonelh_prd." + user_input)
        df_results = get_create_table_statements(table_names)
 
        output_file = "Data_Analysis_report.xlsx"
        save_to_excel(df_results, output_file)
        st.write("### Analysis Started ...")
        analyze_sql_queries_from_excel(output_file)
       
        Total_transformation_count = sum_total_transformations(output_file)
        print("Total Sum:", Total_transformation_count)
       
        st.write("### Layer counting started...")
        layer_count = str(layer_finding(user_input))
        layer_numeric_value = int(re.search(r'\d+', layer_count).group())
       
        st.write("### Direct views counting...")
        direct_asset_count = str(direct_asset(user_input))
        direct_asset_numeric_value = int(re.search(r'\d+', direct_asset_count).group())
        print(direct_asset_numeric_value)
 
        final_data = {
            "Data_asset_parameter": [
                "Data conversion",
                "Aggregations/Transformations Layers",
                "No of Tables/Views involved in the Joins of View SQL",
                "No of views that directly makes an asset"
            ],
            "Count": [
                int(Total_transformation_count),
                int(layer_numeric_value),
                int(count_of_all_tables),
                int(direct_asset_numeric_value)
            ]
        }
 
        final_df = pd.DataFrame(final_data)
        st.write("## Complexity Matrix ")
        st.table(final_df)
       
        xlsx_filepath = "Data_Analysis_report.xlsx"
       
        with open(xlsx_filepath, "rb") as file:
            file_data = file.read()
            st.download_button(
                label="Download Data Asset Analysis Report",
                data=file_data,
                file_name="Data_Analysis_report.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )